<!DOCTYPE html>
<html>

<head>
	<title>ONLINE VOTING PORTAL | ELECTIONS 2020 </title>
	<link rel="stylesheet" type="text/css" href="main2.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<marquee>Welcome To Online Voting Portal</marquee>


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

</head>

<body>

	<div class="header">
		<h1 style="color: #6d2557"> <img src=eci2.jpg class="img-rounded" alt="eci" /> ELECTIONS</h1>

	</div>

	<br />

	<ul>
		<li><a href="main2.html"><span class="glyphicon glyphicon-home"></span>Home</a></li>
		  <li><a href="userreg.php"><span class="glyphicon glyphicon-user"></span>User Registration</a></li>
		  <li><a href="userlogin.php"><span class="glyphicon glyphicon-log-in"></span>User Login</a></li>
		  <li><a href="candireg.php"><span class="glyphicon glyphicon-user"></span>Candidte Registration</a></li>
		  <li><a href="clogin.php"><span class="glyphicon glyphicon-log-in"></span>Candidate Login</a></li>
		  <li><a href="adminlogin.php"><span class="glyphicon glyphicon-lock"></span>Admin Login</a></li>
		   <li><a href="regulation.php"><span class="glyphicon glyphicon-book"></span>Regulations </a></li>
		    <li><a href="yourconstituency.php"><span class="glyphicon glyphicon-flag">Your constituency</a></li>
		   <li><a href="yourcandidate.php"><span class="glyphicon glyphicon-user"></span>Your candidate</a></li>
		   <li><a href="contactus.php"><span class="glyphicon glyphicon-phone">Contact_Us</a></li>
		   <li><a href="https://eci.gov.in/ " target="_blank"><span class="glyphicon glyphicon-circle-arrow-right"></span>ECI</a></li>
  
	</ul>
	

	<div class="footer">
		<p>&copy for BMSCE. All Rights Reserved. 2021</p>
	</div>

</body>

</html>