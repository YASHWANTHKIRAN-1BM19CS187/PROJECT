<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title> CONSTITUENCIES | BENGALURU</title>
<style>
h2
  {
      text-align: center;
      text-decoration: underline;
      color: white;
      font-style: italic;
  }

  p
  {
    text-align: center;
    top: 50%;
    text-decoration-style: solid;
    text-shadow: all;
    font-size: 20px;
  }
.dropbtn {
  background-color: green;
  color: white;
  padding: 12px;

  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;

}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: white;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: orangered;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  
}

.dropdown-content a:hover {background-color: #2F4F4F;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
.dropdown{left: 600px;}
body
{
  background-image: url(beng.jpg);
  background-repeat: no-repeat;
  background-size: height: cover";
  background-attachment: scroll;
}



</style>
</head>
<body>

<h2><b>ABOUT YOUR CONSTITUENCY</b></h2>
<p><i>Select Your Constituency</i></p>

<div class="dropdown" style="float: center;">
  <button class="dropbtn">Constituency</button>
  <div class="dropdown-content">
    <a href="https://en.wikipedia.org/wiki/Bangalore">BENGALURU </a>
  
  </div>
</div>

</body>
</html>
