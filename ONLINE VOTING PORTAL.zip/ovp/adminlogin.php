<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>AdminLogin</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
<style>
 body {
      background-color: "red";
      font-family: Georgia, serif;
      background-image: url('Admin_back.jpg');
      background-position: center center;
      background-size: cover;
      background-repeat: no-repeat;
      background-attachment: fixed;
    }
* {box-sizing: border-box}

h1{
  text-align: center;
  font-size: xx-large;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 50%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: 2px solid rgb(0, 0, 0);
  background: rgb(207, 196, 196);
  background-color:  rgb(219, 197, 197);
  color: rgb(0, 0, 0);
  border-radius: 15px 15px 15px;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: rgba(255, 99, 71, 0.2);
  border: 2px solid rgba(255, 0, 0, 0.589);
  outline: none;
  color: white;
}
,
h,r {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color: green;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
  border-radius: 15px 50px;
}

button:hover {
  opacity:1;
  border-radius: 15px 50px;
}

/* Extra styles for the cancel button */


/* Float cancel and signup buttons and add an equal width */
.resetbtn {
      padding: 14px 15px;
      background-color: red;
      border-radius: 15px 50px;
    }

    /* Float cancel and signup buttons and add an equal width */
    .resetbtn,
    .signupbtn {
      float: left;
      width: 10%;
      border-radius: 15px 50px;
    }

/* Add padding to container elements */
.container {
  padding: 16px;
  color: rgb(255, 255, 255);
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .resetbtn, 
  .signupbtn {
     width: 100%;
  }
}

a {
  padding: 1px 1px;
      background-color: rgb(255, 255, 255);
      border-radius: 15px;
a:hover {
    color: red;
    background: #eff;
}

</style>
</head>
<body>
<?php


$username=filter_input (INPUT_POST, 'username');
$password=filter_input (INPUT_POST, 'psw');
$mysqli=new mysqli("localhost:3306","root","","ovp",);

if($mysqli->connect_errno)
{
	echo "Failed:(".
	$mysqli->connect_errno.")".$mysqli->connection_error;
}


    require('db.php');
    session_start();
    // When form submitted, check and create user session.
    if (isset($_POST['username'])) {
        $username = stripslashes($_REQUEST['username']);    // removes backslashes
        $username = mysqli_real_escape_string($con, $username);
        $password = stripslashes($_REQUEST['password']);
        $password = mysqli_real_escape_string($con, $password);
        // Check user is exist in the database
        $query    = "SELECT * FROM `adminlogin` WHERE username='$username'
                     AND password='$password'";
        $result = mysqli_query($con, $query) or die(mysqli_error($con));
        $rows = mysqli_num_rows($result);
        if ($rows == 1) {
            $_SESSION['username'] = $username;
            // Redirect to user dashboard page
            header("Location: cpanel.php");
        } else {
            echo "<div class='form'>
                  <h3>Incorrect Username/password.</h3><br/>
                  <p class='link'>Click here to <a href='adminlogin.php'>Login</a> again.</p>
                  </div>";
        }
    } else {
?>
    <form class="form" method="post" name="login">
        <h1 class="login-title">ADMIN LOGIN</h1>
        <input type="text" class="login-input" name="username" placeholder="Username" autofocus="true" required/>
        <input type="password" class="login-input" name="password" placeholder="Password" required/>
        <div class="clearfix">
      <button type="reset" class="resetbtn" value="Reset">RESET</button>
      <button id="register" class="signupbtn" value="Submit" onclick="return Validate()" / >LOGIN</button>
      <a style="color: rgb(255, 0, 0)" href="main2.php">HOME </a>
      

    

    
      
  </form>




<?php
    }
?>
</body>
</html>
