<!DOCTYPE html>
<html>
<head>
	<title>Regulations | E-Voting 2020</title>
	<link rel="stylesheet" type="text/css" href="regulation.css">
</head>
<body>
<p>
<h1> REGULATIONS FOR ELCTIONS 2020 </h1>
<ul>
<li>No party or candidate shall include in any activity which may aggravate existing differences or create mutual hatred or cause tension between different castes and communities, religious or linguistic.<br /></li>
<li>Criticism of other political parties, when made, shall be confined to their policies and programme, past record and work. Parties and Candidates shall refrain from criticism of all aspects of private life, not connected with the public activities of the leaders or workers of other parties. Criticism of other parties or their workers based on unverified allegations or distortion shall be avoided.<br /></li>
<li>There shall be no appeal to caste or communal feelings for securing votes. Mosques, Churches, Temples or other places of worship shall not be used as forum for election propaganda.<br /></li>
<li>All parties and candidates shall avoid scrupulously all activities which are “corrupt practices” and offences under the election law, such as bribing of voters, intimidation of voters, impersonation of voters, canvassing within 100 meters of polling stations, holding public meetings during the period of 48 hours ending with the hour fixed for the close of the poll, and the transport and conveyance of voters to and from polling station.<br /></li>
<li>The right of every individual for peaceful and undisturbed home-life shall be respected, however much the political parties or candidates may resent his political opinions or activities. Organizing demonstrations or picketing before the houses of individuals by way of protesting against their opinions or activities shall not be resorted to under any circumstances.<br /></li>
<li>No political party or candidate shall permit its or his followers to make use of any individual’s land, building, compound wall etc., without his permission for erecting flag-staffs, suspending banners, pasting notices, writing slogans etc.<br /></li>
<li>Political parties and candidates shall ensure that their supporters do not create obstructions in or break up meetings and processions organized by other parties. Workers or sympathisers of one political party shall not create disturbances at public meetings organized by another political party by putting questions orally or in writing or by distributing leaflets of their own party. Processions shall not be taken out by one party along places at which meetings are held by another party. Posters issued by one party shall not be removed by workers of another party.<br /></li>
</ul>
</p>
</body>
</html>