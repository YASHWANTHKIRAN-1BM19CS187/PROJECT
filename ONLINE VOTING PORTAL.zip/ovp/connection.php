<?php 
$con = mysqli_connect("localhost:3307","root","","polltest") or die ("error" . mysqli_error($con));
?>
