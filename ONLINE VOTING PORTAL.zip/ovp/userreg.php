<!DOCTYPE html>
<html>
<head>
  <title>USER REGISTRATION | ELECTIONS  </title>
</head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<body>

  <style>
    body
    h1{
      text-align: center;
      font-size: xx-large;
    }
    * {
      font-family: Georgia, serif;
    }

    * {
      box-sizing: border-box;
    }

    /* Full-width input fields */
    input[type=text],
    input[type=password] {
      width: 50%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: 2px solid rgb(0, 0, 0);
      background: rgb(240, 240, 240);
      background-color: rgb(232, 232, 232);
      border-radius: 15px 15px 15px;
    }

    input[type=text]:focus,
    input[type=password]:focus {
      background-color: rgba(255, 99, 71, 0.2);
      border: 2px solid rgba(255, 0, 0, 0.58);
      outline: none;
    }

    h,
    r {
      border: 1px solid #f1f1f1;
      margin-bottom: 25px;
    }

    /* Set a style for all buttons */
    button {
      background-color: #33cc33;
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 100%;
      opacity: 0.9;
      border-radius: 15px 50px;
    }

    button:hover {
      opacity: 1;
    }

    /* Extra styles for the cancel button */
    .resetbtn {
      padding: 14px 20px;
      background-color: rgb(255, 0, 0);
      border-radius: 15px 50px;
    }

    /* Float cancel and signup buttons and add an equal width */
    .resetbtn,
    .signupbtn {
      float: left;
      width: 50%;
    }

    /* Add padding to container elements */
    .container {
      padding: 16px;

    }

    /* Clear floats */
    .clearfix::after {
      content: "";
      clear: both;
      display: table;
    }

    /* Change styles for cancel button and signup button on extra small screens */
    @media screen and (max-width: 200px) {

      .resetbtn,
      .signupbtn {
        width: 100%;
      }
    }

    a {
  padding: 1px 1px;
      background-color: rgb(255, 255, 255);
      border-radius: 15px;
a:hover {
    color: red;
    background: #eff;
}



  </style>

  <body style="background-image: url(User_Reg.png); background-position: center center;
      background-size: cover;
      background-repeat: no-repeat;
      background-attachment: fixed;">

    <form action="uregister.php" method="post"checkpassword style="border:1px solid #ccc">
    

    <h1>USER REGISTRATION</h1>
      <hr>
      <a style="color: rgb(255, 0, 0)" href="userlogin.php">already registered</a>
      <hr>
      <label for="fname"><b>First Name:* </b></label>
      <input type="text" id="fname" name="firstname"  placeholder="Enter first name"   pattern="[A-Za-z]{1,}" title="MUST CONTAIN ONLY LETTERS" required>
      <hr>

      <label for="lname"><b>Last Name:* </b></label>
      <input type="text" id="lname" name="lastname"  placeholder="Enter last name"  pattern="[A-Za-z]{1,}" title="MUST CONTAIN ONLY LETTERS" required>


      <hr>

      <label for="dob"><b>DOB:*</b></label>
      <input type="date" name="date"  placeholder="dd-mm-yyyy"  value="" min="1900-01-01" max="2002-12-31"  required>


      <hr>

      <label><b>Please select your gender:* </b></label>
      <label class="btn btn-default btn-lg">
        <input type="radio" name="gender" value="Female" required><i class="fa fa-female"></i> Female
      </label>
      <label class="btn btn-default btn-lg">
        <input type="radio" name="gender" value="Male"><i class="fa fa-male"></i> Male
      </label>
      <input type="radio" id="other" name="gender" value="other">
      <label for="other">Other</label>

      <hr>

      <label for="phone"><b>Contact number:* </b></label>
      <input type="tel" id="phone" name="phone" pattern="[0-9]{10}" title="MUST CONTAIN ONLY NUMBERS" required>

   <hr>

      <label for="email"><b>Email:* </b></label>
      <input type="text" placeholder="Enter Email (Example:-abcdef123@gmail.com/.ac.in)" name="email" id="email"
      name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="THE SAME MAIL ID SHOULD BE USED FOR LOGIN" required>
      <hr>

      <label for="myInput"><b>Password:* </b></label>
      <input type="password" placeholder="Enter Password" name="psw" id="myInput"
        pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
        title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"
        required>

        <input type="checkbox" onclick="myFunction()">Show password
        <script>
        function myFunction() {
          var x = document.getElementById("myInput");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        }
        </script>


      <hr>
      <label for="psw-conf"><b>Confirm Password:* </b></label>
      <input type="password" placeholder="Confirm Password" name="psw-conf" id="psw-conf" name="psw-conf" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
        title="Must be same as the password entered above" required onchange='check_pass();'/>

        <script type="text/javascript">
          function Validate() {
              var password = document.getElementById("myInput").value;
              var confirmPassword = document.getElementById("psw-conf").value;
              if (password != confirmPassword) {
                  alert("Passwords do not match.");
                  return false;
              }
              return true;
          }
      </script>

      <hr>


      <label>
        <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
      </label>

      <label>
        <p>By creating an account you agree to our <a href="t&p.html" style="color:rgb(1, 14, 126)">Terms & Privacy of this
            website</a>.</p>
            <p>All the fields marked * are mandatory.</p>
      </label>


      <div class="clearfix">
        <button type="reset" class="resetbtn" value="Reset">Reset</button>
        <button id="register" class="signupbtn" onclick="return Validate()" / >Register</button>

      </div>

    </form>

  </body>

</html>