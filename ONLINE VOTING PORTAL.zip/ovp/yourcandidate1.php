<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title> CANDIDATES | BENGALURU</title>
<style>
h2
  {
      text-align: center;
      text-decoration: underline;
      color: orangered;
  }

  p
  {
    text-align: center;
    top: 50%;
    text-decoration-style: solid;
    text-shadow: all;
    font-size: 20px;
  }
.dropbtn {
  background-color: black;
  color: white;
  padding: 12px;

  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;

}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: black;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: orangered;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  
}

.dropdown-content a:hover {background-color: #2F4F4F;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
.dropdown{left: 600px;}




body
{
  background-image: url(parlmo.jpg);
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: scroll;
}
</style>
</head>
<body>

<h2><b>Your Representatives</b></h2>
<p><i>Select Your Constituency</i></p>

<div class="dropdown" style="float: center;">
  <button class="dropbtn">Constituency</button>
  <div class="dropdown-content">
    <a href="BNCAN1.html">BENGALURU NORTH</a>
    <a href="BSCAN1.html">BENGALURU SOUTH</a>
    <a href="BCCAN1.html">BENGALURU CENTRAL</a>
    <a href="BRCAN1.html">BENGALURU RURAL</a>
  </div>
</div>



</body>
</html>
