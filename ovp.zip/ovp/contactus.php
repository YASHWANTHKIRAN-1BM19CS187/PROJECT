<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <title>CONTACT US</title>
  <link rel="stylesheet" href="style.css"> 
</head>
<body>
	
	<h1>CONTACT US</h1>
	
	<div class="container">
		<div class="card">
			<div class="imgBox"><img src="yash.jpg"></div>
			<h4>ADMIN</h4>
			<h5>YASHWANTH KIRAN S</h5>
			<p></p>
			<p>

			</p>
			
		</div>

		<div class="card">
			<div class="imgBox"><img src="vaghu.jpg"></div>
			<h4>ADMIN</h4>
			<h5>VAGHDEVI PRAVEEN T</h5>
			<p></p>
			<p>
				
			</p>
			<p>

			</p>
		<a href = "mailto: admin.ovp@gmail.com">CONTACT</a>
		</div>
		
		

		<div class="card">
			<div class="imgBox"><img src="sus.jpg"></div>
			<h4>ADMIN</h4>
			<h5>SUSHMITHA Y V</h5>
			<p>

			</p>
			<p>
				
			</p>
		
		</div>
		
	</div>
</body>
</html>
