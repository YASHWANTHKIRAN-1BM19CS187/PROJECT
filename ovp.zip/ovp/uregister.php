<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Registration</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
<style>
 body {
      background-color: "red";
      font-family: Georgia, serif;
      background-image: url('vote_new.jpg');
      background-position: center center;
      background-size: cover;
      background-repeat: no-repeat;
      background-attachment: fixed;
    }
* {box-sizing: border-box}

h1{
  text-align: center;
  font-size: xx-large;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 50%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: 2px solid rgb(0, 0, 0);
  background: rgb(207, 196, 196);
  background-color:  rgb(219, 197, 197);
  color: rgb(0, 0, 0);
  border-radius: 15px 15px 15px;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: rgba(255, 99, 71, 0.2);
  border: 2px solid rgba(255, 0, 0, 0.589);
  outline: none;
  color: white;
}
,
h,r {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color: green;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
  border-radius: 15px 50px;
}

button:hover {
  opacity:1;
  border-radius: 15px 50px;
}

/* Extra styles for the cancel button */


/* Float cancel and signup buttons and add an equal width */
.resetbtn {
      padding: 14px 15px;
      background-color: red;
      border-radius: 15px 50px;
    }

    /* Float cancel and signup buttons and add an equal width */
    .resetbtn,
    .signupbtn {
      float: left;
      width: 10%;
      border-radius: 15px 50px;
    }

/* Add padding to container elements */
.container {
  padding: 16px;
  color: rgb(255, 255, 255);
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .resetbtn, 
  .signupbtn {
     width: 100%;
  }
}

a {
  padding: 1px 1px;
      background-color: rgb(255, 255, 255);
      border-radius: 15px;
a:hover {
    color: red;
    background: #eff;
}

</style>
</head>
<body>


<?php
$firstname=filter_input (INPUT_POST, 'firstname');
$lastname=filter_input (INPUT_POST, 'lastname');
$dob=filter_input (INPUT_POST, 'date');
$gender=filter_input (INPUT_POST, 'gender');
$contactnumber=filter_input (INPUT_POST, 'phone');
$email=filter_input (INPUT_POST, 'email');
$password=filter_input (INPUT_POST, 'psw');
$confirmpassword=filter_input (INPUT_POST, 'psw-conf');
$mysqli=new mysqli("localhost","root","","ovp","3306");

if($mysqli->connect_errno)
{
	echo "Failed:(".
	$mysqli->connect_errno.")".$mysqli->connection_error;
}
else
{
	$password = md5($password);
	$confirmpassword = md5($confirmpassword);
	$sql = "INSERT INTO userregistration (FirstName,LastName,DOB,GENDER,contactnumber,EMAIL,PASSWORD,CONFIRMPASSWORD) values ('$firstname','$lastname','$dob','$gender','$contactnumber','$email','$password','$confirmpassword')";
	if ($mysqli->query($sql)){
		echo " SUCCESSFULLY REGISTERED!!! ";
		echo "<a href= 'userlogin.php'>Click here to Login </a>";
		
	}
	else{
		echo "EMAIL-ID ALREADY REGISTERED !!
		TRY REGISTERING WITH DIFFERENT EMAIL ID !!
		";
		echo "<a href= 'userlogin.php'>or CLICK HERE TO LOGIN</a>";
	}

	$mysqli->close();
}

?>
