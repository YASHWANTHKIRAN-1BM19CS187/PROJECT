<?php
$firstname=filter_input (INPUT_POST, 'firstname');
$lastname=filter_input (INPUT_POST, 'lastname');
$dob=filter_input (INPUT_POST, 'date');
$gender=filter_input (INPUT_POST, 'gender');
$contactnumber=filter_input (INPUT_POST, 'phone');
$currentaddress=filter_input (INPUT_POST, 'currentaddress');
$constituency=filter_input (INPUT_POST, 'constituency');
$email=filter_input (INPUT_POST, 'email');
$password=filter_input (INPUT_POST, 'psw');
$confirmpassword=filter_input (INPUT_POST, 'psw-conf');
$mysqli=new mysqli("localhost","root","","ovp","3306");

if($mysqli->connect_errno)
{
	echo "Failed:(".
	$mysqli->connect_errno.")".$mysqli->connection_error;
}
else
{
	$password = md5($password);
	$confirmpassword = md5($confirmpassword);
	$sql = "INSERT INTO candidateregistration (FirstName,LastName,DOB,GENDER,CONTACTNUMBER,currentaddress,constituency,EMAIL,PASSWORD,CONFIRMPASSWORD) values ('$firstname','$lastname','$dob','$gender','$contactnumber','$currentaddress','$constituency','$email','$password','$confirmpassword')";
	if ($mysqli->query($sql)){
		echo " SUCCESSFULLY REGISTERED!!! ";
		echo "<a href= 'clogin.php'>Clich here to Login </a>";
		
	}
	else{
		echo "email-id already registered
		". $mysqli->error;
	}

	$mysqli->close();
}

?>