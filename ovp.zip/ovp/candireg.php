<!DOCTYPE html>
<html>
  <head>
    <title>CANDIDATE REGISTRATION | ELECTIONS 2020 </title>
  </head>
<style>
 body {
      background-color: "red";
      font-family: Georgia, serif;
      background-image: url('bg3.jpg');
      background-position: center center;
      background-size: cover;
      background-repeat: no-repeat;
      background-attachment: fixed;
    }
* {box-sizing: border-box}

h1{
  text-align: center;
  font-size: xx-large;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 50%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: 2px solid rgb(0, 0, 0);
  background: rgb(207, 196, 196);
  background-color:  rgb(219, 197, 197);
  color: rgb(0, 0, 0);
  border-radius: 15px 15px 15px;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: rgba(255, 99, 71, 0.2);
  border: 2px solid rgba(255, 0, 0, 0.589);
  outline: none;
  color: white;
}
,
h,r {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color: green;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
  border-radius: 15px 50px;
}

button:hover {
  opacity:1;
  border-radius: 15px 50px;
}

/* Extra styles for the cancel button */


/* Float cancel and signup buttons and add an equal width */
.resetbtn {
      padding: 14px 20px;
      background-color: red;
      border-radius: 15px 50px;
    }

    /* Float cancel and signup buttons and add an equal width */
    .resetbtn,
    .signupbtn {
      float: left;
      width: 50%;
      border-radius: 15px 50px;
    }

/* Add padding to container elements */
.container {
  padding: 16px;
  color: rgb(255, 255, 255);
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .resetbtn, 
  .signupbtn {
     width: 100%;
  }
}

a {
  padding: 1px 1px;
      background-color: rgb(255, 255, 255);
      border-radius: 15px;
a:hover {
    color: red;
    background: #eff;
}

</style>

<body>

<form action="cregister.php" method="post" checkpassword verification style="border:1px solid #ccc">

  <div class="container">
    <h1>CANDIDATE REGISTRATION</h1>
  <div>
    <a style="color: rgb(0, 1, 78)" href="clogin.php">already registered</a>
</div>
  <hr>
    <label for="fname"><b>First Name :*</b></label>
    <input type="text" id="fname" name="firstname"  placeholder="Enter first name"   pattern="[A-Za-z]{1,}" title="MUST CONTAIN ONLY LETTERS" required>
<hr>
    <label for="lname"><b>Last Name :*</b></label>
    <input type="text" id="lname" name="lastname"  placeholder="Enter last name"   pattern="[A-Za-z]{1,}" title="MUST CONTAIN ONLY LETTERS"   required>
<hr>
    <label for="dob"><b>DOB :* <b/></label>
      <input type="date" name="date"  placeholder="dd-mm-yyyy"  value="" min="1900-01-01" max="2002-12-31"  required>
<hr>
  <p>Please select your gender: *</p>
<label class="btn btn-default btn-lg">
<input type="radio" name="gender" value="Female" required><i class="fa fa-female"></i> Female
                </label>
                <label class="btn btn-default btn-lg">
                  <input type="radio" name="gender" value="Male"><i class="fa fa-male"></i> Male
                </label>
  <input type="radio" id="other" name="gender" value="other">
  <label for="other">Other</label>

<hr>
  <label for="phone">Contact number :*</label><br><br>
  <input type="tel" id="phone" name="phone" pattern="[0-9]{10}" title="MUST CONTAIN ONLY NUMBERS" required>

<hr>

   <label for="address"><b>Current Address :*</b></label>
   <input type="text" id="caddress" name="currentaddress" placeholder="Enter your current address" required>

<hr>

<p>Please select your Constituency: *</p>
<label class="btn btn-default btn-lg">
<input type="radio" name="constituency" value="BENGALURU NORTH" required><i class="fa fa-BENGALURU NORTH"></i> BENGALURU NORTH
                </label>
                <label class="btn btn-default btn-lg">
                  <input type="radio" name="constituency" value="BENGALURU SOUTH"><i class="fa fa-BENGALURU SOUTH"></i>BENGALURU SOUTH
                </label>
                <input type="radio" name="constituency" value="BENGALURU CENTRAL"><i class="fa fa-BENGALURU CENTRAL"></i>BENGALURU CENTRAL
                </label>
  <input type="radio" id="consti" name="constituency" value="BENGALURU RURAL">
  <label for="BENGALURU RURAL">BENGALURU RURAL</label>

<hr>
    <label for="email"><b>Email :* </b></label>
    <input type="text" placeholder="Enter Email (Example:-abcdef123@gmail.com/.ac.in)" name="email" id="email"
      name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="THE SAME MAIL ID SHOULD BE USED FOR LOGIN" required>
<hr>
    <label for="psw"><b>Password :* </b></label>
    <input type="password" placeholder="Enter Password" name="psw" id="myInput" name="psw" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>

    <input type="checkbox" onclick="myFunction()">Show password

    <script>
    function myFunction() {
      var x = document.getElementById("myInput");
      if (x.type === "password") {
        x.type = "text";
      } else {
        x.type = "password";
      }
    }
    </script>


<hr>
    <label for="psw-conf"><b>Confirm Password :* </b></label>
    <input type="password" placeholder="Confirm Password" name="psw-conf" id="psw-conf" name="psw-conf" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must be same as the password entered above" required>
    <label>

      <script type="text/javascript">
        function Validate() {
            var password = document.getElementById("myInput").value;
            var confirmPassword = document.getElementById("psw-conf").value;
            if (password != confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }
            return true;
        }
    </script>

<hr>
      <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
    </label>
    
    <p>By registering you agree to our <a href="t&p.html"color:rgb(1, 8, 105)">Terms & Privacy of this website</a>.</p>
    <p>All the fields marked * are mandatory.</p>
    <div class="clearfix">
      <button type="reset" class="resetbtn" value="Reset">Reset</button>
      <button id="register" class="signupbtn" value="Submit" onclick="return Validate()" / >Register</button>

     
    </div>
  </div>
</form>

</body>
</html>
