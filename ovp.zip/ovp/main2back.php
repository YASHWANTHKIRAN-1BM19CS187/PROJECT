<!DOCTYPE html>
<html>

<head>
	<title>ONLINE VOTING PORTAL | ELECTIONS 2020 </title>
	<link rel="stylesheet" type="text/css" href="main2back.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

</head>

<body>

	<div class="header">
		<h1 style="color: #6d2557"> <img src=eci2.jpg class="img-rounded" alt="eci" /> </h1>

	</div>

	<br />

	<ul>
		<li><a href="main2.html"><span class="glyphicon glyphicon-home"></span>Home</a></li>
		  
		  <li><a href="userloginnew.html"><span class="glyphicon glyphicon-log-in"></span>Login</a></li>
                  
		   


	</ul>


	<div class="footer">
		<p>&copy for BMSCE. All Rights Reserved. 2020</p>
	</div>

</body>

</html>